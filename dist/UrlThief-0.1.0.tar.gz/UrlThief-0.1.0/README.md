# URLThief

============================

## Introduction

This module will capture the URL from active browser from Firefox, Chrome, Brave, Opera and Edge browsers. It is currently supported in Windows operating system with **uiautomation** supported; and Linux operating system working with **Xlib** Desktop manager.