import pylru

lru = pylru.lrucache(size=20)